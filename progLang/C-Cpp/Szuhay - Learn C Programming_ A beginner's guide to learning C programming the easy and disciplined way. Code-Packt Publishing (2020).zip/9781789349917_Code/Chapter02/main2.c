//  main2.c
//  Chapter 2
//  Learn C Programming
//
//  Adding a simple function. 
//  The program still does nothing.
//
// Compile with:
//
//    cc main2.c -Wall -Werror -std=c11
//

void printComma()
{

  // ... means 0 or more statements could go here.

  return;
}

int main()
{

  // ... means 0 or more statements could go here.

  return 0;
}

//  <eof>
