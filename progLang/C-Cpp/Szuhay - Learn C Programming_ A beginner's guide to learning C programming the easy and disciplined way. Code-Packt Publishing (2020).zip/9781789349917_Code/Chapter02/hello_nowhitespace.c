// hello_nowhitespace.c
// Chapter 2
// Learn C Programming
//
// We're saving spaces but so what?
// This is really bad programming style.
//
// Compile with:
//
//    cc hello_nowhitespace.c -Wall -Werror -std=c11
//

#include<stdio.h>
int main(){printf("Hello, world!\n");}
