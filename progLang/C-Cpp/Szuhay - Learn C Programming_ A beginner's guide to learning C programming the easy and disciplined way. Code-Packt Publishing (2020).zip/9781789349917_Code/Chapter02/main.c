//  main.c
//  Chapter 2
//  Learn C Programming
//
//  The very minimal and useless C program.
//  We do this only for illustrative purpose, no other.
//
// Compile with:
//
//    cc main.c -Wall -Werror -std=c11
//

int main( void )
{
  return 0;
}

//  <eof>
